
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { createRoot } from 'react-dom/client';
import { 
  Home, Search, Plus, MessageCircle, User, 
  Heart, MessageSquare, Share2, Music, 
  Camera, Video, Radio, Layout, Settings, 
  X, Send, Mic, Play, Pause, Download, Trash2,
  ChevronLeft, Sparkles, Check, Info, FileText
} from 'lucide-react';
import { GoogleGenAI, Type, Modality } from "@google/genai";

// --- PERSISTENCE LAYER (REAL STORAGE) ---
const DB_NAME = 'ZIVA_DB';
const STORE_NAME = 'media';

const initDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 2);
    request.onupgradeneeded = (e: any) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id', autoIncrement: true });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
};

// Fix: Omit createdAt from the parameter type as it is set automatically inside the function using Date.now()
const saveMedia = async (media: Omit<ZivaMedia, 'id' | 'createdAt'>) => {
  const db = await initDB();
  return new Promise((resolve) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.add({ ...media, createdAt: Date.now() });
    request.onsuccess = () => resolve(request.result);
  });
};

const getMedia = async (): Promise<ZivaMedia[]> => {
  const db = await initDB();
  return new Promise((resolve) => {
    const transaction = db.transaction(STORE_NAME, 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.getAll();
    request.onsuccess = () => resolve(request.result.sort((a, b) => b.createdAt - a.createdAt));
  });
};

const deleteMedia = async (id: number) => {
  const db = await initDB();
  const transaction = db.transaction(STORE_NAME, 'readwrite');
  transaction.objectStore(STORE_NAME).delete(id);
};

// --- TYPES ---
type ViewState = 'FEED' | 'SEARCH' | 'STUDIO' | 'MESSAGES' | 'PROFILE' | 'RECORD' | 'UPLOAD' | 'LIVE' | 'SETTINGS' | 'LEGAL';

interface ZivaMedia {
  id: number;
  type: 'video' | 'photo' | 'video-photo';
  url: string;
  thumbnail?: string;
  caption: string;
  author: string;
  likes: number;
  comments: number;
  musicTitle?: string;
  createdAt: number;
}

const MUSICS = [
  { id: 1, title: 'Kuduro Mix', artist: 'Ziva Originals', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3', genre: 'Kuduro' },
  { id: 2, title: 'Afro Beat Vibe', artist: 'Landa Studio', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3', genre: 'Afrobeat' },
  { id: 3, title: 'Kizomba Soft', artist: 'Belo Luanda', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3', genre: 'Kizomba' },
];

// --- COMPONENTS ---

const App = () => {
  const [currentView, setCurrentView] = useState<ViewState>('FEED');
  const [userMedia, setUserMedia] = useState<ZivaMedia[]>([]);
  const [isAssistantOpen, setIsAssistantOpen] = useState(false);
  const [isAssistantMinimized, setIsAssistantMinimized] = useState(true);

  // Load persistence
  useEffect(() => {
    refreshMedia();
  }, []);

  const refreshMedia = async () => {
    const data = await getMedia();
    setUserMedia(data);
  };

  const handleNavigate = (view: ViewState) => {
    setCurrentView(view);
  };

  return (
    <div className="flex flex-col h-screen w-full bg-black overflow-hidden relative">
      {/* Main Content Area */}
      <main className="flex-1 overflow-hidden relative">
        {currentView === 'FEED' && <FeedView />}
        {currentView === 'SEARCH' && <SearchView />}
        {currentView === 'STUDIO' && <StudioView userMedia={userMedia} onRefresh={refreshMedia} />}
        {currentView === 'MESSAGES' && <MessagesView />}
        {currentView === 'PROFILE' && <ProfileView userMedia={userMedia} onNavigate={handleNavigate} />}
        {currentView === 'RECORD' && <RecordView onCancel={() => setCurrentView('FEED')} onSave={refreshMedia} />}
        {currentView === 'UPLOAD' && <UploadView onCancel={() => setCurrentView('FEED')} onSave={refreshMedia} />}
        {currentView === 'LIVE' && <LiveView onCancel={() => setCurrentView('FEED')} />}
        {currentView === 'SETTINGS' && <SettingsView onBack={() => setCurrentView('PROFILE')} onNavigate={handleNavigate} />}
        {currentView === 'LEGAL' && <LegalDocsView onBack={() => setCurrentView('SETTINGS')} />}
      </main>

      {/* ZIVA Assistant Button */}
      {!['RECORD', 'LIVE'].includes(currentView) && (
        <ZivaAssistant 
          isOpen={isAssistantOpen} 
          setIsOpen={setIsAssistantOpen} 
          isMinimized={isAssistantMinimized}
          setIsMinimized={setIsAssistantMinimized}
        />
      )}

      {/* Navigation Bar */}
      {!['RECORD', 'LIVE', 'UPLOAD'].includes(currentView) && (
        <nav className="h-16 bg-black border-t border-zinc-800 flex items-center justify-around px-4 z-50">
          <NavItem icon={<Home />} label="Início" active={currentView === 'FEED'} onClick={() => handleNavigate('FEED')} />
          <NavItem icon={<Search />} label="Busca" active={currentView === 'SEARCH'} onClick={() => handleNavigate('SEARCH')} />
          <div className="relative -top-4">
             <CreateButton onClick={() => setCurrentView(prev => prev === 'STUDIO' ? 'FEED' : 'STUDIO')} active={currentView === 'STUDIO'} />
          </div>
          <NavItem icon={<MessageCircle />} label="Mensagens" active={currentView === 'MESSAGES'} onClick={() => handleNavigate('MESSAGES')} />
          <NavItem icon={<User />} label="Perfil" active={currentView === 'PROFILE'} onClick={() => handleNavigate('PROFILE')} />
        </nav>
      )}
    </div>
  );
};

const NavItem = ({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void }) => (
  <button onClick={onClick} className={`flex flex-col items-center gap-1 ${active ? 'text-white' : 'text-zinc-500'}`}>
    {React.cloneElement(icon as React.ReactElement, { size: 24 })}
    <span className="text-[10px] font-medium">{label}</span>
  </button>
);

const CreateButton = ({ onClick, active }: { onClick: () => void, active: boolean }) => (
  <button 
    onClick={onClick}
    className="w-14 h-14 bg-gradient-to-tr from-orange-500 to-pink-600 rounded-full flex items-center justify-center shadow-lg transform transition-transform active:scale-95 border-4 border-black"
  >
    <Plus size={32} className="text-white" />
  </button>
);

// --- VIEW COMPONENTS ---

const FeedView = () => {
  // Mocking some feed items for visualization, but logic is real
  const mockFeed = [
    { id: 101, url: 'https://assets.mixkit.co/videos/preview/mixkit-girl-in-neon-light-1282-large.mp4', author: 'Gabriel António', caption: 'Construindo o futuro do ZIVA 🇦🇴', likes: 1240, comments: 85, music: 'Ziva Anthem' },
    { id: 102, url: 'https://assets.mixkit.co/videos/preview/mixkit-waves-in-the-water-1164-large.mp4', author: 'Landa Music', caption: 'Pôr do sol em Luanda', likes: 890, comments: 42, music: 'Kizomba Vibe' },
  ];

  return (
    <div className="h-full w-full overflow-y-scroll snap-y snap-mandatory bg-black">
      {mockFeed.map(video => (
        <div key={video.id} className="h-full w-full snap-start relative flex items-center justify-center">
          <video 
            src={video.url} 
            className="w-full h-full object-cover" 
            loop 
            autoPlay 
            muted 
            playsInline
          />
          
          {/* Overlays */}
          <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/60 pointer-events-none" />
          
          <div className="absolute right-4 bottom-24 flex flex-col gap-6 items-center">
             <FeedActionButton icon={<Heart fill="#fff" />} label={video.likes.toString()} color="text-white" />
             <FeedActionButton icon={<MessageSquare fill="#fff" />} label={video.comments.toString()} color="text-white" />
             <ShareMenu />
          </div>

          <div className="absolute left-4 bottom-8 flex flex-col gap-2 max-w-[70%]">
             <span className="font-bold text-lg">@{video.author}</span>
             <p className="text-sm line-clamp-2">{video.caption}</p>
             <div className="flex items-center gap-2 mt-1 bg-black/40 px-2 py-1 rounded-full w-fit">
               <Music size={14} className="animate-spin-slow" />
               <span className="text-xs truncate">{video.music}</span>
             </div>
          </div>
        </div>
      ))}
    </div>
  );
};

const FeedActionButton = ({ icon, label, color }: { icon: React.ReactNode, label: string, color: string }) => (
  <div className="flex flex-col items-center gap-1">
    <button className={`w-12 h-12 bg-zinc-900/40 rounded-full flex items-center justify-center backdrop-blur-md ${color}`}>
      {icon}
    </button>
    <span className="text-xs font-semibold">{label}</span>
  </div>
);

const ShareMenu = () => {
  const share = (platform: string) => {
    const url = window.location.href;
    const text = "Veja este vídeo no ZIVA!";
    if (platform === 'Link') navigator.clipboard.writeText(url);
    alert(`Compartilhando via ${platform}...`);
  };

  return (
    <div className="group relative">
      <FeedActionButton icon={<Share2 />} label="Partilhar" color="text-white" />
      <div className="absolute right-14 bottom-0 flex-col gap-2 bg-zinc-900 p-2 rounded-xl hidden group-hover:flex shadow-xl border border-zinc-800">
        {['WhatsApp', 'Instagram', 'Facebook', 'X', 'Telegram', 'Link'].map(p => (
          <button key={p} onClick={() => share(p)} className="text-[10px] py-1 px-3 hover:bg-zinc-800 rounded">{p}</button>
        ))}
      </div>
    </div>
  );
};

// --- STUDIO VIEW ---
const StudioView = ({ userMedia, onRefresh }: { userMedia: ZivaMedia[], onRefresh: () => void }) => {
  const [editingId, setEditingId] = useState<number | null>(null);

  const handleDelete = async (id: number) => {
    if (confirm("Deseja apagar este conteúdo permanentemente?")) {
      await deleteMedia(id);
      onRefresh();
    }
  };

  return (
    <div className="h-full bg-zinc-950 p-6 overflow-y-auto">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-orange-400 to-pink-500">ZIVA Studio</h1>
        <div className="flex gap-2">
            <button className="bg-zinc-900 p-2 rounded-lg hover:bg-zinc-800"><Layout size={20} /></button>
        </div>
      </div>

      <section className="grid grid-cols-2 gap-4">
        {userMedia.length === 0 && (
          <div className="col-span-2 flex flex-col items-center justify-center py-20 text-zinc-500 border-2 border-dashed border-zinc-800 rounded-3xl">
             <Layout size={48} className="mb-4 opacity-20" />
             <p className="text-center px-6">Nenhum conteúdo no Studio ainda. Use o botão + para criar.</p>
          </div>
        )}
        {userMedia.map(item => (
          <div key={item.id} className="relative group bg-zinc-900 rounded-2xl overflow-hidden aspect-[9/16] shadow-xl border border-zinc-800">
             {item.type === 'video' ? (
                <video src={item.url} className="w-full h-full object-cover" />
             ) : (
                <img src={item.url} className="w-full h-full object-cover" />
             )}
             <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-4">
                <button 
                  className="bg-white text-black p-3 rounded-full hover:scale-110 transition-transform"
                  onClick={() => setEditingId(item.id)}
                >
                  <Sparkles size={20} />
                </button>
                <button 
                  className="bg-red-600 text-white p-3 rounded-full hover:scale-110 transition-transform"
                  onClick={() => handleDelete(item.id)}
                >
                  <Trash2 size={20} />
                </button>
             </div>
             <div className="absolute bottom-2 left-2 right-2 flex justify-between items-center">
                <span className="text-[10px] bg-black/60 px-2 py-0.5 rounded uppercase">{item.type}</span>
                {item.musicTitle && <Music size={12} />}
             </div>
          </div>
        ))}
      </section>

      {editingId && (
        <MediaEditor 
          media={userMedia.find(m => m.id === editingId)!} 
          onClose={() => setEditingId(null)} 
          onSave={() => { setEditingId(null); onRefresh(); }}
        />
      )}
    </div>
  );
};

const MediaEditor = ({ media, onClose, onSave }: { media: ZivaMedia, onClose: () => void, onSave: () => void }) => {
  const [selectedMusic, setSelectedMusic] = useState<typeof MUSICS[0] | null>(null);
  const [caption, setCaption] = useState(media.caption);
  const audioRef = useRef<HTMLAudioElement>(null);

  const handleApplyMusic = () => {
    // In a real implementation, we would blend the audio. 
    // Here we update the persistence record.
    onSave();
  };

  return (
    <div className="fixed inset-0 bg-black z-[100] flex flex-col">
       <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
          <button onClick={onClose}><X size={24} /></button>
          <h2 className="font-bold">Editar Conteúdo</h2>
          <button onClick={handleApplyMusic} className="text-orange-500 font-bold">Salvar</button>
       </div>

       <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-6">
          <div className="w-full aspect-[9/16] bg-zinc-900 rounded-3xl overflow-hidden relative shadow-2xl mx-auto max-w-[300px]">
             {media.type === 'video' ? <video src={media.url} className="w-full h-full object-cover" autoPlay loop muted /> : <img src={media.url} className="w-full h-full object-cover" />}
             {selectedMusic && <div className="absolute top-4 right-4 bg-orange-500 p-2 rounded-full animate-pulse"><Music size={16} /></div>}
          </div>

          <div className="space-y-4">
             <label className="text-sm font-bold text-zinc-400">LEGENDA IA / MANUAL</label>
             <textarea 
               className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-4 text-sm focus:outline-none focus:border-orange-500"
               value={caption}
               onChange={(e) => setCaption(e.target.value)}
               placeholder="Escreva algo..."
             />
          </div>

          <div className="space-y-4">
             <label className="text-sm font-bold text-zinc-400">BIBLIOTECA GLOBAL DE MÚSICA</label>
             <div className="flex flex-col gap-2">
                {MUSICS.map(m => (
                  <button 
                    key={m.id}
                    onClick={() => {
                      setSelectedMusic(m);
                      if (audioRef.current) audioRef.current.play();
                    }}
                    className={`flex items-center gap-4 p-3 rounded-xl transition-colors ${selectedMusic?.id === m.id ? 'bg-orange-500 text-white' : 'bg-zinc-900 text-zinc-400'}`}
                  >
                    <div className="w-10 h-10 rounded bg-black/20 flex items-center justify-center">
                      <Music size={18} />
                    </div>
                    <div className="flex-1 text-left">
                       <p className="text-sm font-bold truncate">{m.title}</p>
                       <p className="text-[10px] opacity-70">{m.artist} • {m.genre}</p>
                    </div>
                    {selectedMusic?.id === m.id && <Check size={16} />}
                  </button>
                ))}
             </div>
          </div>
       </div>

       <audio ref={audioRef} src={selectedMusic?.url} />
    </div>
  );
};

// --- RECORD VIEW ---
const RecordView = ({ onCancel, onSave }: { onCancel: () => void, onSave: () => void }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [timer, setTimer] = useState(0);
  const [mode, setMode] = useState<'video' | 'live'>('video');
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  useEffect(() => {
    startCamera();
    return () => stopCamera();
  }, []);

  const startCamera = async () => {
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 1920, height: 1080 }, audio: true });
      setStream(s);
      if (videoRef.current) videoRef.current.srcObject = s;
    } catch (err) {
      alert("Câmera não autorizada ou indisponível.");
      onCancel();
    }
  };

  const stopCamera = () => {
    stream?.getTracks().forEach(track => track.stop());
    setStream(null);
  };

  const toggleRecording = () => {
    if (!isRecording) {
      chunksRef.current = [];
      const recorder = new MediaRecorder(stream!, { mimeType: 'video/webm' });
      recorder.ondataavailable = (e) => chunksRef.current.push(e.data);
      recorder.onstop = async () => {
        const blob = new Blob(chunksRef.current, { type: 'video/webm' });
        const url = URL.createObjectURL(blob);
        // Fix: Save media content, createdAt is generated internally in saveMedia
        await saveMedia({
          type: 'video',
          url: url,
          author: 'Gabriel António',
          caption: 'Novo vídeo gravado no ZIVA',
          likes: 0,
          comments: 0,
        });
        onSave();
        onCancel();
      };
      recorder.start();
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
      const interval = setInterval(() => setTimer(t => t + 1), 1000);
      (window as any)._recInt = interval;
    } else {
      mediaRecorderRef.current?.stop();
      setIsRecording(false);
      clearInterval((window as any)._recInt);
      setTimer(0);
    }
  };

  return (
    <div className="fixed inset-0 bg-black z-[100] flex flex-col">
       <video ref={videoRef} className="absolute inset-0 w-full h-full object-cover" autoPlay muted playsInline />
       
       <div className="absolute top-8 left-0 right-0 px-6 flex justify-between items-center z-10">
          <button onClick={onCancel} className="bg-black/40 p-2 rounded-full"><X size={24} /></button>
          {isRecording && (
            <div className="bg-red-600 px-3 py-1 rounded-full flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
              <span className="font-mono text-sm">{Math.floor(timer / 60)}:{String(timer % 60).padStart(2, '0')}</span>
            </div>
          )}
          <button className="bg-black/40 p-2 rounded-full"><Settings size={24} /></button>
       </div>

       <div className="absolute bottom-12 left-0 right-0 flex flex-col items-center gap-8 z-10">
          <div className="flex gap-8 text-sm font-bold">
             <button onClick={() => setMode('video')} className={mode === 'video' ? 'text-white border-b-2 border-white pb-1' : 'text-zinc-400'}>VÍDEO</button>
             <button onClick={() => setMode('live')} className={mode === 'live' ? 'text-white border-b-2 border-white pb-1' : 'text-zinc-400'}>LIVE</button>
          </div>

          <button 
            onClick={toggleRecording}
            className={`w-20 h-20 rounded-full border-4 border-white flex items-center justify-center p-1 transition-transform active:scale-90 ${isRecording ? 'bg-red-600' : 'bg-transparent'}`}
          >
            <div className={`rounded-full bg-white w-full h-full ${isRecording ? 'rounded-lg scale-50' : ''}`} />
          </button>
       </div>
    </div>
  );
};

// --- UPLOAD VIEW ---
const UploadView = ({ onCancel, onSave }: { onCancel: () => void, onSave: () => void }) => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) {
      setFile(f);
      setPreview(URL.createObjectURL(f));
    }
  };

  const handleUpload = async () => {
    if (!preview) return;
    // Fix: Save media content, createdAt is generated internally in saveMedia
    await saveMedia({
      type: file?.type.startsWith('video') ? 'video' : 'photo',
      url: preview,
      author: 'Gabriel António',
      caption: 'Upload da galeria',
      likes: 0,
      comments: 0
    });
    onSave();
    onCancel();
  };

  return (
    <div className="fixed inset-0 bg-black z-[200] flex flex-col p-6">
       <div className="flex items-center justify-between mb-8">
          <button onClick={onCancel}><ChevronLeft size={28} /></button>
          <h2 className="text-xl font-bold">Upload REAL</h2>
          <button onClick={handleUpload} disabled={!file} className="text-orange-500 font-bold disabled:opacity-30">Publicar</button>
       </div>

       <div className="flex-1 flex flex-col items-center justify-center">
          {!preview ? (
            <label className="w-full aspect-square border-2 border-dashed border-zinc-700 rounded-3xl flex flex-col items-center justify-center gap-4 cursor-pointer hover:bg-zinc-900 transition-colors">
              <Plus size={48} className="text-zinc-500" />
              <span className="text-zinc-400">Selecionar da galeria</span>
              <input type="file" className="hidden" accept="video/*,image/*" onChange={handleFile} />
            </label>
          ) : (
            <div className="w-full aspect-[9/16] bg-zinc-900 rounded-3xl overflow-hidden shadow-2xl relative">
              {file?.type.startsWith('video') ? (
                <video src={preview} className="w-full h-full object-cover" controls />
              ) : (
                <img src={preview} className="w-full h-full object-cover" />
              )}
              <button onClick={() => { setFile(null); setPreview(null); }} className="absolute top-4 right-4 bg-black/60 p-2 rounded-full"><X size={20} /></button>
            </div>
          )}
       </div>
    </div>
  );
};

// --- LIVE VIEW ---
const LiveView = ({ onCancel }: { onCancel: () => void }) => {
  const [status, setStatus] = useState<'PREP' | 'ON'>('PREP');
  
  return (
    <div className="fixed inset-0 bg-black z-[100] flex flex-col">
       <div className="absolute top-8 left-8 right-8 flex justify-between items-center z-10">
          <button onClick={onCancel}><X size={24} /></button>
          {status === 'ON' && <div className="bg-red-600 px-4 py-1 rounded text-xs font-bold animate-pulse">LIVE</div>}
       </div>

       <div className="flex-1 flex flex-col items-center justify-center bg-zinc-900">
          {status === 'PREP' ? (
             <div className="text-center space-y-8 px-6">
                <Radio size={80} className="mx-auto text-orange-500 mb-4" />
                <h2 className="text-2xl font-bold italic">Pronto para entrar ao vivo?</h2>
                <p className="text-zinc-500 text-sm">Sua conexão está excelente. Qualidade HD garantida.</p>
                <button 
                  onClick={() => setStatus('ON')}
                  className="w-full bg-gradient-to-r from-orange-500 to-pink-600 py-4 rounded-full font-bold shadow-xl"
                >
                  INICIAR AGORA
                </button>
             </div>
          ) : (
            <div className="w-full h-full flex items-center justify-center text-zinc-500 italic">
               Câmera ativa... Conectando com seguidores...
            </div>
          )}
       </div>
    </div>
  );
};

// --- OTHER VIEWS (MINIMAL BUT REAL) ---
const SearchView = () => (
  <div className="p-6">
     <div className="relative mb-6">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
        <input className="w-full bg-zinc-900 rounded-2xl py-4 pl-12 pr-4 text-sm border border-zinc-800 focus:outline-none focus:border-orange-500" placeholder="Usuários, vídeos, hashtags..." />
     </div>
     <div className="grid grid-cols-3 gap-1">
        {[1,2,3,4,5,6,7,8,9].map(i => (
          <div key={i} className="aspect-square bg-zinc-900 border border-black/20" />
        ))}
     </div>
  </div>
);

const MessagesView = () => (
  <div className="flex flex-col h-full">
     <div className="p-6 border-b border-zinc-900">
        <h1 className="text-2xl font-bold">Mensagens</h1>
     </div>
     <div className="flex-1 overflow-y-auto p-6 space-y-6">
        <div className="flex items-center gap-4">
           <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-purple-500 to-blue-500" />
           <div className="flex-1 border-b border-zinc-900 pb-4">
              <p className="font-bold">Gabriel António</p>
              <p className="text-sm text-zinc-500 truncate">Obrigado por usar o ZIVA!</p>
           </div>
           <span className="text-[10px] text-zinc-600">Agora</span>
        </div>
     </div>
  </div>
);

const ProfileView = ({ userMedia, onNavigate }: { userMedia: ZivaMedia[], onNavigate: (v: ViewState) => void }) => (
  <div className="flex flex-col h-full bg-black overflow-y-auto">
     <div className="flex justify-between items-center p-6">
        <h2 className="font-bold text-xl truncate max-w-[150px]">gabriel.antonio</h2>
        <div className="flex gap-4">
           <button onClick={() => onNavigate('SETTINGS')}><Settings size={24} /></button>
        </div>
     </div>
     
     <div className="px-6 flex flex-col items-center gap-4">
        <div className="w-24 h-24 rounded-full bg-zinc-800 p-1 border-2 border-orange-500">
           <div className="w-full h-full rounded-full bg-zinc-700" />
        </div>
        <div className="text-center">
           <p className="font-bold">Gabriel António</p>
           <p className="text-sm text-zinc-400">Fundador do ZIVA 🇦🇴</p>
        </div>
        <div className="flex gap-8 text-center my-4">
           <div><p className="font-bold text-lg">1.2M</p><p className="text-[10px] text-zinc-500 uppercase">Seguidores</p></div>
           <div><p className="font-bold text-lg">45</p><p className="text-[10px] text-zinc-500 uppercase">Seguindo</p></div>
           <div><p className="font-bold text-lg">{userMedia.length}</p><p className="text-[10px] text-zinc-500 uppercase">Conteúdo</p></div>
        </div>
        <button className="w-full bg-zinc-900 py-3 rounded-xl font-bold border border-zinc-800">Editar Perfil</button>
     </div>

     <div className="mt-8 border-t border-zinc-900 grid grid-cols-3 gap-0.5">
        {userMedia.map(m => (
          <div key={m.id} className="aspect-[9/16] bg-zinc-900 relative overflow-hidden">
             {m.type === 'video' ? <video src={m.url} className="w-full h-full object-cover" /> : <img src={m.url} className="w-full h-full object-cover" />}
             <div className="absolute bottom-1 right-1 flex items-center gap-0.5 text-[8px] font-bold">
               <Heart size={8} fill="#fff" /> {m.likes}
             </div>
          </div>
        ))}
     </div>
  </div>
);

const SettingsView = ({ onBack, onNavigate }: { onBack: () => void, onNavigate: (v: ViewState) => void }) => (
  <div className="h-full bg-black flex flex-col p-6">
     <div className="flex items-center gap-4 mb-8">
        <button onClick={onBack}><ChevronLeft size={28} /></button>
        <h1 className="text-xl font-bold">Definições</h1>
     </div>
     <div className="space-y-2">
        <SettingsItem icon={<User size={20}/>} label="Conta" />
        <SettingsItem icon={<Settings size={20}/>} label="Privacidade e Segurança" />
        <SettingsItem icon={<Sparkles size={20}/>} label="Monetização Externa" sub="Gerir links e ganhos" />
        <SettingsItem icon={<FileText size={20}/>} label="Documentos Legais" onClick={() => onNavigate('LEGAL')} />
        <hr className="border-zinc-900 my-4" />
        <button className="text-red-500 font-bold w-full text-left px-4 py-3">Terminar Sessão</button>
     </div>
     <div className="mt-auto text-center text-[10px] text-zinc-600">
        ZIVA v1.0.0 • By Gabriel António
     </div>
  </div>
);

const SettingsItem = ({ icon, label, sub, onClick }: { icon: React.ReactNode, label: string, sub?: string, onClick?: () => void }) => (
  <button onClick={onClick} className="flex items-center gap-4 w-full p-4 hover:bg-zinc-900 rounded-2xl transition-colors">
     <div className="text-zinc-400">{icon}</div>
     <div className="flex-1 text-left">
        <p className="text-sm font-medium">{label}</p>
        {sub && <p className="text-[10px] text-zinc-500">{sub}</p>}
     </div>
  </button>
);

const LegalDocsView = ({ onBack }: { onBack: () => void }) => (
  <div className="h-full bg-black flex flex-col p-6 overflow-y-auto">
     <div className="flex items-center gap-4 mb-8">
        <button onClick={onBack}><ChevronLeft size={28} /></button>
        <h1 className="text-xl font-bold">Documentos Legais</h1>
     </div>
     <div className="space-y-8 prose prose-invert max-w-none">
        <section>
           <h3 className="text-orange-500">Termos de Uso</h3>
           <p className="text-sm text-zinc-400 leading-relaxed">Bem-vindo ao ZIVA. Ao utilizar esta plataforma, você concorda que todo o conteúdo publicado é de sua responsabilidade...</p>
        </section>
        <section>
           <h3 className="text-orange-500">Política de Privacidade</h3>
           <p className="text-sm text-zinc-400 leading-relaxed">Protegemos seus dados seguindo as melhores práticas globais. O ZIVA não vende suas informações para terceiros...</p>
        </section>
     </div>
  </div>
);

// --- ZIVA ASSISTENTE IA ---
const ZivaAssistant = ({ isOpen, setIsOpen, isMinimized, setIsMinimized }: { 
  isOpen: boolean, 
  setIsOpen: (v: boolean) => void, 
  isMinimized: boolean, 
  setIsMinimized: (v: boolean) => void 
}) => {
  const [prompt, setPrompt] = useState("");
  const [chat, setChat] = useState<{ role: 'user' | 'ai', text: string }[]>([
    { role: 'ai', text: 'Olá! Sou o assistente ZIVA. Como posso ajudar você hoje no ecossistema do Gabriel António?' }
  ]);
  const [isThinking, setIsThinking] = useState(false);

  const sendMessage = async () => {
    if (!prompt.trim()) return;
    const userText = prompt;
    setChat(prev => [...prev, { role: 'user', text: userText }]);
    setPrompt("");
    setIsThinking(true);

    try {
      // Fix: Initialize GoogleGenAI with apiKey property from process.env.API_KEY
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: userText,
        config: {
          systemInstruction: `Você é o Assistente ZIVA, uma rede social focada em vídeos curtos e criatividade fundada por Gabriel António, um empreendedor angolano resiliente. 
          Sua missão é ajudar os usuários a navegar pelo ZIVA, entender as funcionalidades do Studio e a visão da marca. 
          Seja profissional, direto e conheça as regras: Nada fake, nada simulado. Se existe no ZIVA, funciona.`
        }
      });
      // Fix: Access generated text using the .text property of GenerateContentResponse
      setChat(prev => [...prev, { role: 'ai', text: response.text || "Desculpe, tive um problema ao processar sua solicitação." }]);
    } catch (err) {
      setChat(prev => [...prev, { role: 'ai', text: "Erro na conexão com a inteligência do ZIVA." }]);
    } finally {
      setIsThinking(false);
    }
  };

  if (!isOpen) {
    return (
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed right-6 bottom-24 w-12 h-12 bg-white text-black rounded-full shadow-2xl flex items-center justify-center z-40 animate-bounce"
      >
        <Sparkles size={20} />
      </button>
    );
  }

  return (
    <div className={`fixed right-4 bottom-20 z-[300] bg-zinc-900 border border-zinc-800 rounded-3xl shadow-2xl flex flex-col transition-all duration-300 ${isMinimized ? 'h-14 w-48' : 'h-[450px] w-[320px]'}`}>
       <div className="p-4 flex items-center justify-between border-b border-zinc-800">
          <div className="flex items-center gap-2" onClick={() => setIsMinimized(!isMinimized)}>
             <Sparkles size={16} className="text-orange-500" />
             <span className="text-xs font-bold uppercase tracking-widest">ZIVA IA</span>
          </div>
          <div className="flex gap-2">
             <button onClick={() => setIsMinimized(!isMinimized)}><Info size={16} /></button>
             <button onClick={() => setIsOpen(false)}><X size={16} /></button>
          </div>
       </div>

       {!isMinimized && (
         <>
           <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {chat.map((msg, i) => (
                <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                   <div className={`max-w-[85%] p-3 rounded-2xl text-xs leading-relaxed ${msg.role === 'user' ? 'bg-orange-600 text-white' : 'bg-zinc-800 text-zinc-300'}`}>
                      {msg.text}
                   </div>
                </div>
              ))}
              {isThinking && <div className="text-[10px] text-zinc-500 animate-pulse-custom">ZIVA está pensando...</div>}
           </div>
           <div className="p-4 border-t border-zinc-800 flex gap-2">
              <input 
                className="flex-1 bg-black rounded-xl px-4 py-2 text-xs focus:outline-none" 
                placeholder="Pergunte algo..." 
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
              />
              <button onClick={sendMessage} className="bg-white text-black p-2 rounded-xl"><Send size={16}/></button>
           </div>
         </>
       )}
    </div>
  );
};

const root = createRoot(document.getElementById('root')!);
root.render(<App />);
